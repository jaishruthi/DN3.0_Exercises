package MVCPatternExample;

public class MVCPatternExample {
    public static void main(String[] args) {
        // Create a Student model
        Student model = new Student("Jaishruthi", "7376212CT117","Computer Technology", 85.0);

        // Create a StudentView
        StudentView view = new StudentView();

        // Create a StudentController
        StudentController controller = new StudentController(model, view);

        // Update student details
        controller.setStudentName("Jaishruthi");
        controller.setStudentId("7376212CT117");
        controller.setStudentdept("Computer Technology");
        controller.setStudentGrade(90.0);

        // Update the view
        controller.updateView();
    }
}