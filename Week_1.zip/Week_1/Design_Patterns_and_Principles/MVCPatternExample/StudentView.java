package MVCPatternExample;

public class StudentView {
    public void displayStudentDetails(String name, String id, String dept, double grade) {
        System.out.println("Student Details:");
        System.out.println("Name: " + name);
        System.out.println("Roll.No: " + id);
        System.out.println("Department: " + dept);
        System.out.println("Grade: " + grade);
    }
}
