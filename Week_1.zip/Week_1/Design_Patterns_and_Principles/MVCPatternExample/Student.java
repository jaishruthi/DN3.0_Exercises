package MVCPatternExample;

// Student.java
public class Student {
    private String name;
    private String id;
    private String dept;
    private double grade;

    public Student(String name, String id, String dept, double grade) {
        this.name = name;
        this.id = id;
        this.dept = dept;
        this.grade = grade;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getdept() {
        return dept;
    }

    public void setdept(String dept) {
        this.dept = dept;
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }
}