package StrategyPatternExample;
public class StrategyPatternExample {
    public static void main(String[] args) {
        ShoppingCart cart = new ShoppingCart();

        Item item1 = new Item(40, 1);
        Item item2 = new Item(60, 2);

        cart.addItem(item1);
        cart.addItem(item2);

        cart.pay(new CreditCardStrategy("Jaishruthi", "1234567890123456", "12/25", "12/25"));
        cart.pay(new PaypalStrategy("myemail@example.com", "mypwd"));
    }
}