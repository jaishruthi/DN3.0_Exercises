package StrategyPatternExample;

public interface PaymentStrategy {
    void pay(int amount);
}