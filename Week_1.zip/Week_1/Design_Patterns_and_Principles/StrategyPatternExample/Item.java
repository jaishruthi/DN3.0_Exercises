package StrategyPatternExample;
public class Item {
    private int price;
    private String upcCode;
    private int quantity;

    public Item(String upc, int price, int quantity) {
        this.upcCode = upc;
        this.price = price;
        this.quantity = quantity;
    }

    public Item(int price, int quantity) {
        this.price = price;
        this.quantity = quantity;
    }

    public String getUpcCode() {
        return upcCode;
    }

    public int getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }
}