package SingletonPatternExample;

public class LoggerTest {
    public static void main(String[] args) {
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();

        // Verify that both logger1 and logger2 refer to the same instance
        System.out.println("logger1 == logger2: " + (logger1 == logger2)); // Output: true

        logger1.log("Hello, World!");
        logger2.log("This is a test log message.");
    }
}
