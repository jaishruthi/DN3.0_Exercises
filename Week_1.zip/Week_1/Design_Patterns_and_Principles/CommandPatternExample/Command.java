package CommandPatternExample;

public interface Command {
    public void execute();
}
