package ProxyPatternExample;

public class ProxyImage implements Image {
    private RealImage realImage;
    private String filename;
    private boolean hasBeenLoaded = false;

    public ProxyImage(String filename) {
        this.filename = filename;
    }

    @Override
    public void display() {
        if (!hasBeenLoaded) {
            realImage = new RealImage(filename);
            hasBeenLoaded = true;
        }
        realImage.display();
    }
}
