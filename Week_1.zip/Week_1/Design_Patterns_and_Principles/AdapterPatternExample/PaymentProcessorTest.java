package AdapterPatternExample;

public class PaymentProcessorTest {
    public static void main(String[] args) {
        // Create payment gateways
        PayPalGateway payPalGateway = new PayPalGateway();
        StripeGateway stripeGateway = new StripeGateway();
        BankTransferGateway bankTransferGateway = new BankTransferGateway();

        // Create adapters
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPalGateway);
        PaymentProcessor stripeAdapter = new StripeAdapter(stripeGateway);
        PaymentProcessor bankTransferAdapter = new BankTransferAdapter(bankTransferGateway);

        // Process payments using adapters
        payPalAdapter.processPayment("Credit Card", 100.0);
        stripeAdapter.processPayment("Debit Card", 50.0);
        bankTransferAdapter.processPayment("Bank Account", 200.0);
    }
}