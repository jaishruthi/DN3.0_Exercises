package AdapterPatternExample;

public interface PaymentProcessor {
    void processPayment(String paymentMethod, double amount);
}