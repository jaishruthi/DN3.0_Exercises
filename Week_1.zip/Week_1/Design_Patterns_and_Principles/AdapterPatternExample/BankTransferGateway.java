package AdapterPatternExample;

public class BankTransferGateway {
    public void transferWithBank(String paymentMethod, double amount) {
        System.out.println("Processing payment of $" + amount + " using Bank Transfer with " + paymentMethod);
    }
}
