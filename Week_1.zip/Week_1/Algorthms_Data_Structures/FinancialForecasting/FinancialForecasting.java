package Algorthms_Data_Structures.FinancialForecasting;

public class FinancialForecasting {
   
    public double calculateFutureValue(double presentValue, double growthRate, int years) {
        if (years == 0) {
            return presentValue;
        } else {
            return calculateFutureValue(presentValue * (1 + growthRate), growthRate, years - 1);
        }
    }

    public static void main(String[] args) {
        FinancialForecasting ff = new FinancialForecasting();
        double presentValue = 7000.0;
        double growthRate = 8;
        int years = 5;

        double futureValue = ff.calculateFutureValue(presentValue, growthRate, years);
        System.out.println("Future value after " + years + " years: " + futureValue);
    }
}
