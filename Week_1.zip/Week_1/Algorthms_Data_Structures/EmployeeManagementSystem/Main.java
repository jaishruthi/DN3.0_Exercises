package Algorthms_Data_Structures.EmployeeManagementSystem;

public class Main {
    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(5);

        ems.addEmployee(new Employee(1, "Jaishruthi", "Software Engineer", 500000.0));
        ems.addEmployee(new Employee(2, "Nisha", "Marketing Manager", 180000.0));
        ems.addEmployee(new Employee(3, "Smrithi", "Sales Representative", 90000.0));

        System.out.println("Employees:");
        ems.traverseEmployees();

        Employee employee = ems.searchEmployeeById(2);
        if (employee!= null) {
            System.out.println("Employee found: " + employee.toString());
        } else {
            System.out.println("Employee not found.");
        }

        ems.deleteEmployeeById(2);

        System.out.println("Employees after deletion:");
        ems.traverseEmployees();
    }
}
