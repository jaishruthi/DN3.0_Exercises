package Algorthms_Data_Structures.LibraryManagementSystem;

public class Main {
    public static void main(String[] args) {
        Book[] books = new Book[] {
                new Book(1, "Book 1", "Author 1"),
                new Book(2, "Book 2", "Author 2"),
                new Book(3, "Book 3", "Author 3"),
                new Book(4, "Book 4", "Author 4"),
                new Book(5, "Book 5", "Author 5")
        };

        LibraryManagementSystem lms = new LibraryManagementSystem(books);

        Book book = lms.linearSearchByTitle("Book 3");
        if (book!= null) {
            System.out.println("Book found using linear search: " + book.toString());
        } else {
            System.out.println("Book not found using linear search.");
        }

        book = lms.binarySearchByTitle("Book 3");
        if (book!= null) {
            System.out.println("Book found using binary search: " + book.toString());
        } else {
            System.out.println("Book not found using binary search.");
        }
    }
}