package Algorthms_Data_Structures.TaskManagementSystem;

public class TaskManagementSystem {
    private Node head;

  
    public TaskManagementSystem() {
        head = null;
    }

    // Add task
    public void addTask(Task task) {
        Node node = new Node(task);
        if (head == null) {
            head = node;
        } else {
            Node temp = head;
            while (temp.getNext() != null) {
                temp = temp.getNext();
            }
            temp.setNext(node);
        }
    }

    // Search task by ID
    public Task searchTaskById(int taskId) {
        Node temp = head;
        while (temp != null) {
            if (temp.getTask().getTaskId() == taskId) {
                return temp.getTask();
            }
            temp = temp.getNext();
        }
        return null;
    }

    // Traverse tasks
    public void traverseTasks() {
        Node temp = head;
        while (temp != null) {
            System.out.println(temp.getTask().toString());
            temp = temp.getNext();
        }
    }

    // Delete task by ID
    public void deleteTaskById(int taskId) {
        if (head == null) {
            return;
        }
        if (head.getTask().getTaskId() == taskId) {
            head = head.getNext();
            return;
        }
        Node temp = head;
        while (temp.getNext() != null) {
            if (temp.getNext().getTask().getTaskId() == taskId) {
                temp.setNext(temp.getNext().getNext());
                return;
            }
            temp = temp.getNext();
        }
    }
}
