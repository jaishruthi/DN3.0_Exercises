package Algorthms_Data_Structures.SortingCustomerOrders;

public class Main {
    public static void main(String[] args) {
        Order[] orders = new Order[] {
            new Order(1, "John Doe", 100.99),
            new Order(2, "Jane Smith", 50.00),
            new Order(3, "Bob Johnson", 200.00),
            new Order(4, "Alice Brown", 75.50)
        };

        System.out.println("Original Orders:");
        for (Order order : orders) {
            System.out.println(order.toString());
        }

        // Bubble Sort
        BubbleSort.bubbleSortByTotalPrice(orders);
        System.out.println("\nOrders sorted by Bubble Sort by their total price:");
        for (Order order : orders) {
            System.out.println(order.toString());
        }

        // Quick Sort
        orders = new Order[] {
            new Order(1, "Jaishruthi", 150.99),
            new Order(2, "Smrithi", 50.00),
            new Order(3,"Bavana", 200.00),
            new Order(4, "Anisha", 175.50)
        };
        QuickSort.quickSortByTotalPrice(orders, 0, orders.length - 1);
        System.out.println("\nOrders sorted by Quick Sort by their total price:");
        for (Order order : orders) {
            System.out.println(order.toString());
        }
    }
}