package Algorthms_Data_Structures.InventoryManagementSystem;

import java.util.HashMap;

public class Inventory {
    private HashMap<Integer, Product> products;

    public Inventory() {
        this.products = new HashMap<>();
    }

    public void addProduct(int productId, Product product) {
        products.put(productId, product);
    }

    public Product getProduct(int productId) {
        if (products.containsKey(productId)) {
            return products.get(productId);
        } else {
            System.out.println("Product not found with ID " + productId);
            return null;
        }
    }

    public static class Product {
        private String name;
        private double price;

        public Product(String name, double price) {
            this.name = name;
            this.price = price;
        }

        public String getName() {
            return name;
        }

        public double getPrice() {
            return price;
        }
    }

    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        Product product1 = new Product("Apple iPhone", 999.99);
        Product product2 = new Product("Samsung TV", 1299.99);

        inventory.addProduct(1, product1);
        inventory.addProduct(2, product2);

        Product retrievedProduct = inventory.getProduct(1);
        if (retrievedProduct!= null) {
            System.out.println("Product found: " + retrievedProduct.getName() + " - $" + retrievedProduct.getPrice());
        } else {
            System.out.println("Product not found");
        }
    }
}