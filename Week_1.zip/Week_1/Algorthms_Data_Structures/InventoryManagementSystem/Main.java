package Algorthms_Data_Structures.InventoryManagementSystem;

public class Main {
    public static void main(String[] args) {
        Product product1 = new Product(1, "Lenskart coolers rosegold frame", 10, 999.99);
        Product product2 = new Product(2, "Metalic frame silver", 5, 1299.99);

        System.out.println("Product ID: " + product1.getProductId());
        System.out.println("Product Name: " + product1.getProductName());
        System.out.println("Quantity: " + product1.getQuantity());
        System.out.println("Price: " + product1.getPrice());
        System.out.println();

        System.out.println("Product ID: " + product2.getProductId());
        System.out.println("Product Name: " + product2.getProductName());
        System.out.println("Quantity: " + product2.getQuantity());
        System.out.println("Price: " + product2.getPrice());
    }
}