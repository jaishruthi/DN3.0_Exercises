package com.BookStoreAPI.BookStore.Controller;

// Exercise - 13
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
//
//    @WebMvcTest(BookController.class)
//    public class BookControllerTest {
//
//        @Autowired
//        private MockMvc mockMvc;
//
//        @MockBean
//        private BookService bookService;
//
//        @Test
//        public void shouldReturnAllBooks() throws Exception {
//            mockMvc.perform(get("/books"))
//                    .andExpect(status().isOk())
//                    .andExpect(jsonPath("$.length()").value(0));
//        }
//    }
//
