package com.BookStoreAPI.BookStore.Entity;

import lombok.Data;

@Data
public class Book {
    private int id;
    private String title;
    private String author;
    private double price;
    private String isbn;

        // Exercise - 8
//        private int id;
//
//        @NotNull(message = "Title cannot be null")
//        @Size(min = 2, message = "Title should have at least 2 characters")
//        private String title;
//
//        @NotNull(message = "Author cannot be null")
//        @Size(min = 2, message = "Author should have at least 2 characters")
//        private String author;
//
//        @Min(value = 1, message = "Price should be greater than 0")
//        private double price;
//
//        @NotNull(message = "ISBN cannot be null")
//        @Size(min = 10, max = 13, message = "ISBN should have 10 to 13 characters")
//        private String isbn;

//          @Id
//          @GeneratedValue(strategy = GenerationType.IDENTITY)
//          private int id;
//
//
//
//          @Version
//          private Integer version;

    // Exercise - 10
//    public int getId() {
//        public EntityModel<Book> getBookById(@PathVariable int id) {
//            Book book = books.stream()
//                    .filter(b -> b.getId() == id)
//                    .findFirst()
//                    .orElseThrow(() -> new RuntimeException("Book not found"));
//
//            return EntityModel.of(book,
//                    WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getAllBooks()).withRel("all-books"));
//        }
//    }

//    public void setId(int id) {
//        this.id = id;
//    }
//
//    public String getTitle() {
//        return title;
//    }
//
//    public void setTitle(String title) {
//        this.title = title;
//    }
//
//    public String getAuthor() {
//        return author;
//    }
//
//    public void setAuthor(String author) {
//        this.author = author;
//    }
//
//    public double getPrice() {
//        return price;
//    }
//
//    public void setPrice(double price) {
//        this.price = price;
//    }
//
//    public String getIsbn() {
//        return isbn;
//    }
//
//    public void setIsbn(String isbn) {
//        this.isbn = isbn;
//    }
}


