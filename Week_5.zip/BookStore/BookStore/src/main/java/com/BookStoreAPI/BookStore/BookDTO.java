import com.fasterxml.jackson.annotation.JsonProperty;

public class BookDTO {
    private int id;

    @JsonProperty("book_title")
    private String title;

    private String author;
    private double price;
    private String isbn;


}
