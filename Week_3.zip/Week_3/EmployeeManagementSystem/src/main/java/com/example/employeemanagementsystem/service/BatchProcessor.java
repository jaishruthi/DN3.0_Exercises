package com.example.employeemanagementsystem.service;

import com.example.employeemanagementsystem.domain.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BatchProcessor {

    @Autowired
    private SessionFactory sessionFactory;

    public void processBatch(List<Employee> employees) {
        Session session = sessionFactory.getCurrentSession();
        session.beginTransaction();

        int batchSize = 20;
        int count = 0;

        for (Employee employee : employees) {
            session.save(employee);
            count++;

            if (count % batchSize == 0) {
                session.flush();
                session.clear();
            }
        }

        session.getTransaction().commit();
    }
}