package com.example.employeemanagementsystem.repository;
import com.example.employeemanagementsystem.domain.Department;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long>{
    List<Department> findByName(String name);

    // 2. Find departments by location
    List<Department> findByLocation(String location);
    @Query("SELECT d FROM Department d WHERE d.employees.size > ?1")
    List<Department> findDepartmentsWithMoreThanXEmployees(Integer numEmployees);


    @PersistenceContext
    @Qualifier("departmentEntityManager")
    private EntityManager entityManager;
}
