package com.example.employeemanagementsystem.repository;
import com.example.employeemanagementsystem.domain.Department;
import com.example.employeemanagementsystem.domain.Employee;
import com.example.employeesystem.projections.DepartmentDetails;
import com.example.employeesystem.projections.EmployeeSummary;
import org.h2.mvstore.Page;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.awt.print.Pageable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<Employee> findByFirstName(String firstName);

    // 2. Find employees by last name
    List<Employee> findByLastName(String lastName);

    // 3. Find employees by department
    List<Employee> findByDepartment(Department department);

    // 4. Find employees by salary range
    List<Employee> findBySalaryBetween(Double minSalary, Double maxSalary);

    @Query("SELECT e FROM Employee e WHERE e.firstName = ?1 AND e.lastName = ?2")
    List<Employee> findEmployeesByFullName(String firstName, String lastName);

    // 2. Find employees who are older than a certain age
    @Query("SELECT e FROM Employee e WHERE e.age > ?1")
    List<Employee> findEmployeesOlderThan(Integer age);

    @Query("SELECT new com.example.employeesystem.projections.EmployeeSummary(e.firstName, e.lastName, d.name) FROM Employee e JOIN e.department d")
    List<EmployeeSummary> findEmployeeSummaries();

    @Query("SELECT new com.example.employeesystem.projections.DepartmentDetails(d.name, COUNT(e)) FROM Employee e JOIN e.department d GROUP BY d.name")
    List<DepartmentDetails> findDepartmentDetails();

    Page<Employee> findAll(Pageable pageable);

    // 2. Find employees by first name with pagination
    Page<Employee> findByFirstName(String firstName, Pageable pageable);

    // 3. Find employees by department with pagination
    Page<Employee> findByDepartment(Department department, Pageable pageable);

    @PersistenceContext
    @Qualifier("employeeEntityManager")
    private EntityManager entityManager;
}
