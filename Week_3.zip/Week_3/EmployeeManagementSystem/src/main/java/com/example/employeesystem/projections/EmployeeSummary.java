package com.example.employeesystem.projections;

public abstract class EmployeeSummary {
    String getFirstName() {
        return null;
    }

    String getLastName() {
        return null;
    }

    String getDepartmentName() {
        return null;
    }
}
