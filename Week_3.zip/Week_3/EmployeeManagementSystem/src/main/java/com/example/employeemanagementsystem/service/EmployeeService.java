package com.example.employeemanagementsystem.service;

import com.example.employeemanagementsystem.domain.Department;
import com.example.employeemanagementsystem.domain.Employee;
import com.example.employeemanagementsystem.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;

import java.awt.print.Pageable;
import java.util.List;

public class EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;
    private BatchProcessor batchProcessor;

    public void saveEmployees(List<Employee> employees) {
        batchProcessor.processBatch(employees);
    }
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id).orElseThrow();
    }

    public Employee createEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public Employee updateEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }
    public Page<Employee> getAllEmployees(Pageable pageable) {
        return (Page<Employee>) employeeRepository.findAll(pageable);
    }

    public Page<Employee> getEmployeesByFirstName(String firstName, Pageable pageable) {
        return (Page<Employee>) employeeRepository.findByFirstName(firstName, pageable);
    }

    public Page<Employee> getEmployeesByDepartment(Department department, Pageable pageable) {
        return (Page<Employee>) employeeRepository.findByDepartment(department, pageable);
    }
}
