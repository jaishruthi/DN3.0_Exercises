package com.example.employeesystem.projections;

public class DepartmentDetails {
    private String departmentName;
    private Long employeeCount;

    public DepartmentDetails(String departmentName, Long employeeCount) {
        this.departmentName = departmentName;
        this.employeeCount = employeeCount;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public Long getEmployeeCount() {
        return employeeCount;
    }
}
