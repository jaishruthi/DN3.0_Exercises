package com.library.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {
    // Repository methods can be added here
    @Override
    public String toString() {
        return "BookRepository instance";
    }
}
