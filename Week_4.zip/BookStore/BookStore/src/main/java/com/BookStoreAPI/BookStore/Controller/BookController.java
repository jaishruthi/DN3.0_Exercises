package com.BookStoreAPI.BookStore.Controller;

import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    private List<Book> books = new ArrayList<>();

    @GetMapping
    public List<Book> getAllBooks() {
        return books;
    }

    @PostMapping
    public Book addBook(@RequestBody Book book) {
        books.add(book);
        return book;
    }

    @PutMapping("/{id}")
    public Book updateBook(@PathVariable int id, @RequestBody Book book) {
        Book existingBook = books.get(id);
        existingBook.setTitle(book.getTitle());
        existingBook.setAuthor(book.getAuthor());
        existingBook.setPrice(book.getPrice());
        existingBook.setIsbn(book.getIsbn());
        return existingBook;
    }

    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable int id) {
        books.remove(id);
    }

    @GetMapping("/{id}")
    public Book getBookById(@PathVariable int id) {
        return books.get(id);
    }

    @GetMapping("/search")
    public List<Book> searchBooks(@RequestParam(required = false) String title,
                                  @RequestParam(required = false) String author) {
        return books.stream()
                .filter(book -> (title == null || book.getTitle().equalsIgnoreCase(title)) &&
                        (author == null || book.getAuthor().equalsIgnoreCase(author)))
                .toList();
    }

    @PostMapping("/customers")
    public Customer createCustomer(@RequestBody Customer customer) {
        // Save customer to database (not implemented here)
        return customer;
    }

    @PostMapping("/customers/register")
    public Customer registerCustomer(@RequestParam String name, @RequestParam String email) {
        Customer customer = new Customer();
        customer.setName(name);
        customer.setEmail(email);
        // Save customer to database (not implemented here)
        return customer;
    }

    @PostMapping("/books")
    @ResponseStatus(HttpStatus.CREATED)
    public Book createBook(@RequestBody Book book) {
        books.add(book);
        return book;
    }

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable int id) {
        Book book = books.get(id);
        return ResponseEntity.ok()
                .header("Custom-Header", "Book-Header")
                .body(book);
    }








}
